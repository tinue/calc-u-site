# Peripherals and paper
