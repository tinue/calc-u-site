# Models and machine control

What a Reset keeps differs by model: [chapter 9](../product/09-product-topics.md).
