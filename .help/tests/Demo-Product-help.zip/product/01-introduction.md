# Introduction

Demo-Product emulates the DM-1.

![The window](images/window.png)

Start with [getting started](../shared/02-getting-started.md#the-control-bar)
and the [tutorial preset](downloads/tutorial.preset).
