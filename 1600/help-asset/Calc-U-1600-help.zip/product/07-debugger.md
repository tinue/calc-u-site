# Debugger on the PC-1500 and PC-1600

The family's debugger (running and paused, traces) is described in
[Debugger](../shared/07-debugger.md). The Calc-U-1600 window
has no run-control buttons: you pause and step from the debugger in VS
Code, and **Machine ▸ Resume** resumes. This page covers what Calc-U-1600
adds: debugging machine code from VS Code, and the INSPECTOR panel.

Calc-U-1600 can debug machine code while it runs, from VS Code (and, not yet
tested, CLion):
- LH5801 code on the PC-1500 and PC-1500A;
- Z80 (SC7852) and LH5803 code on the PC-1600.

You get breakpoints (with conditions, hit counts and log messages), data
breakpoints on memory, stepping by line or by instruction, registers,
memory, disassembly, and your `.asm` source.

This page first covers the one-time installation and setup, then four ways
of working:
1. [Developing your own program](#1-developing-your-own-program)
2. [A program found online](#2-a-program-found-online)
3. [Developing a ROM extension](#3-developing-a-rom-extension)
4. [Firmware analysis](#4-firmware-analysis)

The [Reference](#reference) lists the views, breakpoints, expressions and
every key. The [INSPECTOR](#the-inspector) at the end shows what is in the
machine right now, without a debugger.

```mermaid
flowchart LR
    subgraph IDE["VS Code (or CLion)"]
        ext["Calc-U-1600 extension<br/>configurations, builds, commands"]
    end
    subgraph Project["your folder"]
        asm[".asm source"]
        preset["project preset<br/>debug.pc1600 / .pc1500a"]
    end
    subgraph App["Calc-U-1600"]
        dap["debug server<br/>127.0.0.1:32168"]
        machine["emulated machine"]
    end
    asm -- "zasm / sdaslh5801" --> bin[".bin + listing"]
    ext -- "Debug Adapter Protocol" --> dap
    preset -. "machine set-up + debug: block" .-> dap
    bin -.-> dap
    dap --> machine
```

---

## One-time installation

**1. Turn the debug server on.** In **File ▸ Settings… ▸ Debugger**, set
**Debug server (DAP)** on (`[debug] dap-enabled`, see
[Settings](08-settings.md)). The **Port** is 32168 by default (1024 to
65535), and the **Status** line says whether the server is listening and
whether a debugger is attached. Alternatively, start Calc-U-1600 with
`--dap 32168`: that turns the server on for that run only and leaves the
settings alone. A port outside 1024 to 65535 is reported, and the server
stays off for that run.

**Without a window.** The harness `calcu`, which you build from the source
repository ([Building](https://github.com/tinue/Calc-U/blob/main/docs/Building.md)),
serves a debugger too: `calcu --product c1600 serve --dap 32168`. It has no
wall clock: while VS Code has the machine running, emulated time passes as
fast as the computer allows. A session that stops at breakpoints repeats
exactly; a pause by hand lands wherever the machine got to.

**2. Install the assemblers.**
- **zasm** ([github.com/Megatokio/zasm](https://github.com/Megatokio/zasm)) for PC-1600 (Z80) code.
- **An SDCC build with the LH5801 assembler** for PC-1500 code: `sdaslh5801`, `sdld` and `makebin`.

The extension finds them on your `PATH`, or where the [settings](#setup) say.

**3. Install the VS Code extension.** You need `python3` and VS Code's
`code` command on the `PATH`. From a clone of the source repository, in
`products/calc-u-1600/`:

```sh
tools/install_vscode_extension.sh
```

Then reload the VS Code window. Run the script again after updating
Calc-U-1600. The extension is installed for your user, so it works in every
folder; you don't copy anything into your projects. The extension's own
description is in its
[README](https://github.com/tinue/Calc-U/blob/main/products/calc-u-1600/vscode/calcu1600-debug/README.md).

**4. Optionally, install a language extension** for LH5801 or Z80 assembly.
It adds syntax colouring and lets you set breakpoints by clicking next to a
line. Without one, set `"debug.allowBreakpointsEverywhere": true` in your
VS Code settings.

---

## Setup

The extension's settings are in VS Code's user settings (**Settings ▸
Extensions ▸ Calc-U-1600 Debugger**, or `settings.json`):

| Setting | What it is | Default |
|---|---|---|
| `c1600.port` | the debug server's port | `32168` |
| `c1600.zasmPath` | the zasm executable | `$CALCU_ZASM`, else `zasm` on the `PATH` |
| `c1600.sdccBinPath` | the folder with sdaslh5801, sdld and makebin | `$CALCU_SDCC_BIN`, else the `PATH` |
| `c1600.romListings` | ROM listings that every session loads | none |
| `c1600.romSymbols` | ROM symbol tables that every session loads | none |

**ROM listings** give the firmware source lines and names in every session:
you step through the ROM in its disassembly instead of bare instructions,
and you can set a breakpoint on a routine by name. The PC-1600 ROM
disassemblies in
[github.com/tinue/PC-1600-ROM](https://github.com/tinue/PC-1600-ROM/tree/main/disasm)
reassemble byte for byte with zasm, which writes the listing:

```sh
zasm -uwy PC1600-P0-B0.asm PC1600-P0-B0.lst PC1600-P0-B0.bin
```

Then list it in your settings with the CPU and the bank it lives in:

```jsonc
"c1600.romListings": [
  { "path": "~/PC-1600-ROM/disasm/new/PC1600-P0-B0.lst", "cpu": "z80", "bank": 0 }
]
```

A listing that doesn't match the machine's memory (another ROM variant, for
example) is reported and not used, so a listing for the other model does no
harm.

The PC-1500 ROM disassembly (see the
[acknowledgments](https://github.com/tinue/Calc-U/blob/main/products/calc-u-1600/THIRD-PARTY-NOTICES.md#acknowledgments))
is written for TASM, whose listings the debugger can't read yet.

---

## 1. Developing your own program

You work in the program's own folder. *Create Debug Project…* sets it up
once, and from then on F5 builds, loads and starts it.

**Create the project.** Open an empty folder in VS Code, then run
**Calc-U-1600: Create Debug Project…** from the Command Palette. Choose
*PC-1600 program* or *PC-1500A program* and a name. To put the project into
a subfolder of the workspace instead, right-click that folder in the
Explorer and choose **Calc-U-1600: Create Debug Project Here…**; the launch
configuration then names the folder (`Debug tmp/main`) and points into it.
You get:

| File | What it is |
|---|---|
| `main.asm` | a small program that runs: it prints a greeting on the PC-1600, or counts on the PC-1500A |
| `debug.pc1600` or `debug.pc1500a` | the **project preset**: the machine to run on, and a `debug:` block that tells the debugger what to load |
| `.vscode/launch.json` | one configuration, *Debug main*, that points at the project preset and says which file to build |
| `.gitignore` | the build outputs |

The project preset is an ordinary preset ([Presets](06-presets.md)), so you
can also open it in Calc-U-1600 (**File ▸ Load Preset…**). Calc-U-1600 ignores the
`debug:` block when loading it. The PC-1600 one looks like this:

```yaml
format-version: 2
model: PC-1600

keys:
  - key: mode
  - type: NEW0
  - key: mode

debug:
  program:
    bin: main.bin
    listing: main.lst
    after: stopOnEntry      # type its CALL and stop at the first line
```

Add memory modules, a printer or anything else a preset can hold, and every
debug session starts on that machine.

**Debug.** Press **F5**. VS Code assembles `main.asm`; problems show in the
Problems view. Then Calc-U-1600 does a clean start: it applies the project
preset, loads the program, types its `CALL` and stops at its first line.

**Change and reload.** After an edit, press **Build & Load**
(`Cmd+Alt+L` / `Ctrl+Alt+L`). It rebuilds, does the same clean start and
reloads the program without ending the session. Breakpoints move with the
code. *Restart* in the debug toolbar sets the machine up again from the
configuration.

```mermaid
sequenceDiagram
    participant You
    participant VS as VS Code
    participant App as Calc-U-1600
    You->>VS: F5 / Build & Load
    VS->>VS: assemble (zasm / sdaslh5801)
    VS->>App: attach / load
    App->>App: clean start: project preset
    App->>App: load .bin, bind listing
    App->>App: type CALL (or command)
    App-->>VS: stopped at the entry
```

**Where the program goes.** A headerless `.bin` loads at its listing's
lowest address, the source's `.org`. On the PC-1600, where it ends up also
follows the calculator's MODE and the program area its `TITLE` selects. The
PC-1500A template uses &7C01, the machine-language area BASIC never uses.
The PC-1600 template uses C0C5H, the start of the BASIC program area: fine
while there is no BASIC program. To keep BASIC off your code, put a `NEW`
that reserves it into the preset's `keys:`: on the PC-1500 `NEW &addr` (the
first address after your program), on the PC-1600 `NEW "S0:",n` (n bytes
from the start of the area). When you load a program by hand,
**File ▸ Load Machine Code…** shows the exact `NEW` for it
([Machine-code programs](09-machine-code.md)).

**LH5803 code on the PC-1600.** LH5801 code can also run on the PC-1600's
LH5803. Build it with sdas and give the program `cpu: lh5803` and its LH5803
address. The debugger starts it with `XCALL`, the PC-1600's BASIC command
for LH5803 code, and stops on the LH5803 thread.

**Starting it differently.** In the `debug:` block:
- `entry: START` starts at a symbol (or an address) instead of the default;
- `command: CALL &C0C5,X` types that line instead of the plain `CALL`, e.g.
  to pass a variable to the program;
- `after: call` starts the program without stopping; `after: none`, the
  default, only loads it. The program starts only once VS Code has set your
  breakpoints, so a breakpoint at its first lines is not missed.

---

## 2. A program found online

You collect programs (typically `.bin` files) in one folder, have an AI
agent disassemble each into an `.asm` file, and then want to step through
them. You don't want a configuration per program.

**Debug the file in the editor.** Open the folder, open one `.asm` file, and
pick *Debug current file on PC-1600 (zasm)* or *… on PC-1500A (sdas)* from
the Run and Debug view's list (under *Calc-U-1600*); they are there in every
folder. Pressing **F5** in a folder without a `launch.json` offers the same
choices (if VS Code first asks which debugger, choose *Calc-U-1600*). The
session assembles the file, loads it at its `.org` into a plain machine, and
stops at its first instruction, or at `ENTRY` if the source defines that
label.

**Give one program its own machine.** Some programs need more than a plain
machine: a memory module, a printer, their data, or a `NEW` that reserves
their memory. Put a preset with the program's name next to it:
`DATABROS.pc1600` next to `DATABROS.asm`. *Debug current file* uses the
first preset it finds:

```mermaid
flowchart TD
    start["Debug current file:<br/>FOO.asm"] --> a{"FOO.pc1600 / .pc1500a / .pc1500<br/>next to it?"}
    a -- yes --> useA["use it"]
    a -- no --> b{"debug.pc1600 / .pc1500a / .pc1500<br/>in the folder?"}
    b -- yes --> useB["use it"]
    b -- no --> useC["a plain machine<br/>(bundled with the extension)"]
```

**Tips for disassembled code.**
- Ask the agent to keep the original load address as `.org` and to label
  the entry point `ENTRY`.
- **Don't overwrite the original.** The build writes `<name>.bin` next to
  the source. On a Mac disk, `DATABROS.bin` and `DATABROS.BIN` are the same
  file, so building `DATABROS.asm` next to the original `DATABROS.BIN`
  replaces it. Give the disassembly its own name (`DATABROS-dis.asm`) or keep
  it in a subfolder, then compare the rebuilt `.bin` with the original to
  check that the disassembly is complete.
- Build & Load assembles the file the session started with, even if another
  file is in focus.

---

## 3. Developing a ROM extension

A ROM extension (like Calc-U-1600's own host drive ROM) isn't loaded into
RAM and called. It is plugged into the machine before power-on, and its
code runs from the ROM's own module handling or from BASIC commands. The
debugger supports that too.

**Create the project.** **Calc-U-1600: Create Debug Project…** offers two
ROM targets:

| Target | What you get |
|---|---|
| *PC-1600 ROM extension* | a minimal ROM module (ID, jump table, reset entry) in page 1, bank 6 of the 60-pin connector, built with zasm |
| *PC-1500 ROM extension* | `RENUM`, a new BASIC command in a ROM at &8800 on the 60-pin connector, built with sdaslh5801 (see [the example below](#example-renum-on-the-pc-1500)) |

**Plugging the ROM in.** The project preset's `bus-rom:` puts your `.bin`
on the 60-pin connector ([Preset sections](10-preset-sections.md)):

```yaml
format-version: 2
model: PC-1600

bus-rom:
  - file: rom.bin
    bank: 6                 # PC-1600 system bus: page 1 (4000H-7FFFH), bank 4-7

debug:
  boot: debug
  listings:
    - path: rom.lst
      cpu: z80
      bank: 6
```

On the PC-1500 (or the PC-1600's LH5803 side), a bus ROM has an `address:`
instead of a `bank:`, and it can be limited to one PV / PU state with
`pv:` / `pu:`, like the CE-158's ROM. Each clean start reads the file again,
so F5 and Build & Load always run your latest build. Calc-U-1600 doesn't need
restarting.

**Replacing a bundled ROM.** A bus ROM takes precedence over a built-in
device's ROM at the same place. To work on a new version of the host drive
ROM, for example:

```yaml
format-version: 2
model: PC-1600
host-drive: { folder: files }   # the drive itself: its I/O stays Calc-U-1600's
bus-rom:
  - file: build/hostdrive.bin
    bank: 7                 # your build replaces the bundled bank-7 ROM
```

**Getting into the code.** A real ROM extension is rarely called directly.
It usually adds BASIC commands: the firmware finds the extension at
power-on, activates its commands, and the commands run the extension's
machine code. The `debug:` block has two ways to reach that code:
- **`command:`** types a BASIC line once the machine is up: one of your new
  commands (`RENUM 100,,10` in the PC-1500 template), or `FILES "S3:"` for a
  file device. Set a breakpoint in the code behind it, press F5, and it
  stops there.
- **`boot: debug`** runs the power-on under the debugger. The preset only
  sets the machine up; then the debugger switches it on, with your
  breakpoints armed. That's how you debug a module's reset or
  initialisation, which runs before BASIC's prompt appears. The preset's
  `keys:` are skipped in this mode, and a `program` or `command` is refused.

```mermaid
flowchart LR
    subgraph normal["normal clean start"]
        p1["preset: machine + bus ROMs"] --> b1["boot to the prompt<br/>(no breakpoints)"] --> k1["keys:"] --> c1["command: typed<br/>breakpoints armed"]
    end
    subgraph boot["boot: debug"]
        p2["preset: machine + bus ROMs"] --> r2["power on"] --> b2["boot runs under the debugger<br/>breakpoints armed"]
    end
```

**Build & Load** in a ROM project rebuilds the ROM and does the whole set-up
again: power-on with the new ROM, listings read again, `command` typed (or
the boot run under the debugger).

### Example: RENUM on the PC-1500

The *PC-1500 ROM extension* template is a complete extension: it adds
`RENUM [new][,[old][,step]]` to PC-1500 BASIC, the PC-1600's command for
renumbering a program. The PC-1500 ROM looks for such modules by itself, so
the command works like a built-in one: typed, abbreviated as `REN.`, with
the usual error messages.

1. **Create it.** Open an empty folder, run **Create Debug Project…**, and
   choose *PC-1500 ROM extension*. You get `rom.asm`, `debug.pc1500a` and a
   launch configuration.
2. **Look at the module.** The top of `rom.asm` is what the firmware looks
   for: the `55H` at &8800, the power-on entry `INIT` at &880A, an index by
   first letter, and the keyword table with `RENUM`'s code and address. The
   comments say what each byte means.
3. **Set a breakpoint and press F5.** Put one on `RENUM` (the first
   instruction of the command) or on `RENFIX` (where the references are
   rewritten). F5 builds the ROM, starts a PC-1500A with it, enters the
   sample program from `debug.pc1500a` and types `RENUM 100,,10`. The
   debugger stops at your breakpoint. Step through it, and watch the
   program area in memory (it starts at the address in &7865).
4. **Look at the result.** Continue, switch to PRO mode and `LIST`: the
   lines are now numbered 100, 110, … and every `GOTO`, `GOSUB`, `THEN` and
   `RESTORE` was changed to match. `RUN` (in RUN mode) still prints 3, 2, 1
   and DONE.
5. **Change it.** Edit `rom.asm`, then **Build & Load**: the machine starts
   again with the new ROM and runs `RENUM` again.
6. **Debug the power-on.** Add `boot: debug` to `debug:` (and remove
   `command:`), set a breakpoint on `INIT`, and press F5: the firmware calls
   `INIT` while it starts up.

How the firmware finds a keyword module, and what each field of the table
does, is in [PC-1500 keyword modules](09-keyword-modules.md).

**ROM modules in a memory slot.** A ROM in a memory module (the PC-1500's
module slot, or the PC-1600's Slot 1 or Slot 2) needs two things: a module
definition (`.module.yaml`, see [Module definitions](09-module-definitions.md)
and [the format](10-module-definition-format.md)) that says how the module
decodes, and your `.bin` for what the ROM holds. The module's ROM region
carries a placeholder, so the definition loads on its own:

```yaml
    content: rom
    initial-content:
      blocks:
        - offset: 0x0000
          encoding: addressed-hex
          bytes: |
            $0000: FF...          # placeholder: the preset's slot-1-rom: replaces it
```

The project preset plugs the module in and puts your build into its ROM:

```yaml
slot-1: { file: module.module.yaml }     # or slot-2: on the PC-1600
slot-1-rom: { file: build/module.bin } # read at every clean start
```

The `.bin` must be exactly the ROM's size, so pad it to the full size. Calc-U-1600
never saves such a module back. There is no template for slot modules
yet.

A PC-1500 *BASIC* program module (header, reserve area, program, &FF fill,
closing `65279 END` line) follows Sharp's layout in
[CE-161-Program-Module.md](https://github.com/tinue/Calc-U/blob/main/products/calc-u-1600/docs/developer/CE-161-Program-Module.md#program-modules-in-general);
the system ROM finds it by its &55 header at power-on.

---

## 4. Firmware analysis

You study the calculator's own ROM, in any folder.

**Reset and stop.** Run the ready-made configuration *Calc-U-1600: Reset and
stop*. It uses whatever machine Calc-U-1600 runs, resets it and stops before
the first instruction: E000 on the PC-1500, 0000 on the PC-1600's Z80. Step
from there, or set breakpoints and continue. **Reset & Stop** and
**All Reset & Stop** (a Cold boot) in the Command Palette, and *Restart* in
the debug toolbar, do the same during a session.

**With source.** With the [ROM listings](#setup) in your settings, you step
through the disassembly's source, and you can set a function breakpoint on a
routine by name (`SCANMODS`, say). Listings of banked ROM need their bank
qualifier (`bank:` on the PC-1600, `pv:` / `pu:` on an LH580x), so a
breakpoint in them stops only while that bank is selected.

**A particular machine.** To study the firmware with a printer, a module or
a floppy disk attached, give the configuration a preset. Add a configuration
to the folder's `launch.json`:

```jsonc
{
  "type": "c1600", "request": "attach", "name": "Firmware with CE-1600P",
  "preset": "${workspaceFolder}/with-plotter.pc1600",
  "reset": "reset", "stopOnEntry": true
}
```

---

## CLion

> Not tried yet. CLion 2026.1 and later can use DAP debuggers, including
> over TCP. The recipe below follows JetBrains' documentation; please report
> what works.

CLion sets DAP debuggers up per IDE, not per project. Use a project preset
(as in use cases 1 and 3), so that everything project-specific lives in the
project:

1. **Settings ▸ Build, Execution, Deployment ▸ Debugger ▸ DAP Debuggers:**
   add *Calc-U-1600*.
   - Connection: TCP, port 32168.
   - Executable: Calc-U-1600 with the arguments `--dap $DebuggerPort$`, so
     that CLion starts it for the session. Alternatively, use a placeholder
     executable, if CLion accepts one, to connect to Calc-U-1600 while it
     runs.
   - Launch parameters: `{"project": "$WorkingDir$/debug.pc1600"}`. Attach
     parameters: the same.
2. **Settings ▸ Build, Execution, Deployment ▸ Toolchains:** a toolchain
   whose debugger is *Calc-U-1600*.
3. **A run configuration** (*Custom Build Application*) with the project
   folder as working directory and the build as a *Before launch* external
   tool: `zasm -uwy main.asm main.lst main.bin`, or the sdas commands.

CLion has none of the extension's commands. Restarting the session does what
Build & Load does: build, clean start, load.

What to check:
- does CLion connect to a server it didn't start;
- does it allow breakpoints in `.asm` files;
- does `$WorkingDir$` expand in the launch parameters;
- does the build run before each session.

---

## Reference

### What you see in VS Code

- **Call Stack:** one thread per CPU: `LH5801` on the PC-1500; `Z80 (SC7852)`
  and `LH5803` on the PC-1600, where the CPU that owns the bus is marked
  `[bus]`. A stop always stops both CPUs and names the one that caused it.
  - **Frame 0** is the live state.
  - **Frames 1–20** are the last 20 instructions that CPU executed, newest
    first, e.g. `C0EE  call KEYGET`. Like frame 0, each shows the registers
    *before* its instruction ran, and its source line if it has one; what an
    instruction did shows in the next newer frame (or the live state). An
    interrupt shows as `interrupt at …`, with the registers at the point it
    interrupted. After a data breakpoint, frame 1 is the instruction that
    made the access. The history is always recorded, so it is there even
    when you attach after something went wrong.
- **Variables ▸ Registers:** the selected frame's registers, plus *Flags*
  and, for the live frame, *Banks* (PC-1600 page banks, or PU/PV).
- **Disassembly:** right-click a frame ▸ **Open Disassembly View**. It opens
  by itself where there's no source.
- **Memory:** VS Code shows memory in Microsoft's Hex Editor extension
  (`ms-vscode.hexeditor`), which it offers to install the first time.
  - **Open it:** while paused, hover over a 16-bit register or a Watch entry
    and click **View Binary Data**. A Watch entry can be any address or
    expression, e.g. `0x7600` or `x+0x10`.
  - **Offsets** count from the address you opened. To see real addresses,
    open it from a Watch entry `0`; then **Cmd+G** (Go to offset) jumps
    anywhere.
  - **Edit** in *Replace* mode (status bar, or **Hex Editor: Switch Edit
    Mode**), then save (**Cmd+S**). An insert or a delete can't be saved;
    undo it with **File: Revert File**.
  - **Which CPU:** memory opens as the selected frame's CPU sees it. Select
    an LH5803 frame to see the PC-1600's LH5803 side.
  - Device registers that a read would disturb (the UART, a module's I/O
    window) show as unreadable.
- **Title bar:** the window shows *Paused (debugger)* while the machine is
  paused, whoever paused it; **Machine ▸ Resume** runs it again (also
  without VS Code).

### Stepping

- **Step into / over / out** work by source line. In the Disassembly view
  they work by instruction.
- **Step over** a call (`SJP`, `VEJ`, `VMJ`, `CALL`, `RST` and the
  conditional forms) runs until the stack is back where it was, even when a
  `VMJ`'s inline parameters move the return address.
- **Step out** runs until a return (`RTN`, `RTI`, `RET` …) leaves the
  current routine.
- A long step (over a slow ROM call) keeps the window responsive.

### Breakpoints and expressions

- **Source, function and instruction breakpoints** take a condition
  (`a == 0x10 && [0x7A00] != 0`), a hit count (`5`, `>= 5`, `% 3`) and a log
  message (`x={x}`).
- **Function breakpoints** name a symbol from a listing or symbol table, and
  stop on the CPU that listing belongs to, only while its bank qualifier
  holds.
- **Data breakpoints** watch memory reads and/or writes. Instruction fetches
  don't trigger them. The machine stops right after the instruction that
  made the access. Registers can't be watched; use a conditional breakpoint.
- **Breakpoints stop only while the debugger runs the machine.** A preset, a
  load or a normal boot never stops on one. Use `boot: debug` for code that
  runs at power-on.
- **Expressions** (conditions, Watch, hovers, the Debug Console, register
  edits) accept registers and flags (`cf`, `zf` …), listing symbols,
  `[addr]` (byte), `w[addr]` (word, in the CPU's byte order), `#[addr]` (a
  byte of an LH580x's ME1), and C operators.

### Listings

- **Formats:** sdaslh5801 / sdasz80 `.lst` and the `.rst` sdld writes
  (prefer the `.rst` for relocatable code), zasm `.lst` (`zasm -uwy`), and
  `.SYMBOLS:` tables (`HHHH name` per line).
- **Keep the sources next to the listing.** Neither assembler names the file
  an included line comes from; the debugger finds each line in the source
  files by its text.
- **Checked against memory.** A listing whose bytes don't match memory is
  reported and not used for source: the wrong build, or another ROM variant.
  A frame whose bytes no longer match its line (self-modifying code) shows as
  disassembly.
- **Bank qualifiers** tie a listing, and its breakpoints, to a memory state:

| Qualifier | Meaning |
|---|---|
| `bank` | PC-1600 Z80: the page bank 0–7 selected for the address |
| `me` | LH580x: ME0 or ME1 (code always runs from ME0, so `me: 1` is for data) |
| `pu`, `pv` | LH580x: the PU / PV flip-flops, for code in banked ROMs |

### The `debug:` block and launch configurations

A launch configuration and a project preset's `debug:` block take the same
keys. With `project`, the block supplies whatever the launch configuration
leaves out, and the configuration's own keys win. `program` merges key by
key, and the configuration's `listings` and `symbols` add to the block's
(the extension sends the `c1600.romListings` / `romSymbols` settings
there). The project is read again at every restart and Build & Load.

Numbers (`address`, `entry`, `bank`, `me`, `pu`, `pv`) follow the preset
rule in both places: `&`, `0x` or `$` makes a number hex, a bare number is
decimal. So `address: &C0C5` and `"address": "0xC0C5"` are the same
address; `C0C5` without a prefix is refused (for `entry` it can still be a
symbol). A launch configuration may also give a plain JSON number, which is
decimal.

| Key | Meaning |
|---|---|
| `project` | (launch configuration only) a project preset: it sets the machine up, and its `debug:` block gives the rest |
| `preset` | a preset for the clean start; default: the model's startup preset from the settings, else a Cold boot |
| `program` | the program to load: `bin`, `listing`, `source` (if the main source isn't `<listing>.asm`), `symbols`, `cpu` (`lh5801` / `z80` / `lh5803`), `address`, `entry`, `after` (`stopOnEntry` / `call` / `none`; default `none`), `cleanStart` (default `true`), bank qualifiers |
| `listings` | listings of code that isn't loaded (ROM): a path, or `{path, source, cpu, bank, me, pu, pv}` |
| `symbols` | `.SYMBOLS:` tables: a path, or `{path, cpu, bank, me, pu, pv}` |
| `command` | a BASIC line typed to start the code: in place of the program's `CALL`, or, without a program, once the machine is set up |
| `boot` | `debug`: run the power-on under the debugger (the preset's hardware only; no `program` or `command`) |
| `reset` | `none` (default) / `reset` / `allReset`: a Reset or a Cold boot without the boot, starting at the reset vector |
| `stopOnEntry` | stop right after attaching (after a reset: before the first instruction) |

The VS Code extension adds these keys:

| Key | Meaning |
|---|---|
| `build` | `{assembler: zasm \| sdas, file}`: assemble this file before the session and on Build & Load |
| `buildTask` | a task to run instead, e.g. a Makefile target from `tasks.json` |
| `currentFile` | `pc1600` / `pc1500a`: debug the `.asm` in the editor (use case 2) |
| `port` | the server port, if not `c1600.port` |

The preset sections for ROM development, `bus-rom:` and `debug:`, are listed
with the other sections in [Preset sections](10-preset-sections.md).

### Limitations

- The PC-1600's vertical banks (port 28H, module banks 1 and up) can't be
  used as a bank qualifier.
- ME1 can't be written from the debugger; on both machines it is I/O.
- No stepping backwards.
- The zasm problem matcher shows the first error of each file in the
  Problems view; the terminal shows all of them.
- TASM listings (such as the PC-1500 ROM disassembly) can't be read yet.
- One debugger at a time: a second session is refused while one is attached.
  **File ▸ Settings… ▸ Debugger ▸ Disconnect** drops the attached one; the
  calculator runs on.
- The Web frontend has no debug server.

---

## The INSPECTOR

The INSPECTOR panel shows what is in the machine right now, as text you can
select and copy (while text is selected, **Edit ▸ Copy Screen** reads
**Copy Log Selection** and copies it). To step
through a program or set breakpoints, use the debugger above.

![The INSPECTOR after Pointers](images/09-debug-panel.png)

- **Pointers:** the BASIC and system work-area variables, in groups:
  program, errors and BREAK, variables and stacks, mode and system. Flags
  are decoded (MODE 0/1, RUN/PRO, TRON …). At the end are the derived
  figures, worked out the way the ROM works them out: `MEM`, the program
  size, the machine-language reserve, the variables. On the PC-1600 there
  are also the program areas (`TITLE`, `ADTBL`, S1/S2 with their free
  space), the file buffers, and the SC7852's stack pointer. On a PC-1500 a
  CE-150 or CE-158 adds its own variables.
- **Memory ▾:** tables of the memory.
  - **Inventory:** every ROM and RAM in the machine, built in, in the
    memory slots and on the 60-pin connector, with its size, banks and where
    the CPUs see it.
  - **Z80 View** (PC-1600): what pages A–D of the SC7852 show at the moment,
    with the bank registers and SLOTMAP.
  - **LH5803 View** / **LH5801 View:** the LH5803's (PC-1600) or LH5801's
    (PC-1500) address space at the moment: RAM, display RAM, the peripheral
    ROM window at the current PU/PV, and the I/O in ME1. On the PC-1600 it
    also shows what the LH5803 sees at 0000–3FFF for each kind of work: for
    a PC-1500 statement or `XPEEK`, the program's bank in MODE 1 and in
    MODE 0 whatever the Z-80 left mapped; for functions and arithmetic,
    always what the Z-80 left mapped. Under the table it says whether
    `MODE 1` would be accepted right now, or why it would get ERROR 110.
  - **BASIC Area:** the BASIC area from bottom to top: on the PC-1600 the
    banks it is made of, in `ADTBL` order, with the header,
    machine-language reserve, program, free space and variables in each
    bank.
  - **Program Areas** (PC-1600): S0, S1 and S2 with their start, end, limit
    and free space, and which one `TITLE` selects.
  - **Disk Areas** (PC-1600): the RAM disks S1: and S2:, where they sit in
    the module (on S2: which vertical banks), and what the boot sector says.
  - **Physical RAM:** each RAM chip and what each part of it holds, for
    example "S0: program", "RAM disk S2:" or "unused".
- **Dump ▾:** hex dumps of the BASIC area, a program module's area (S1, S2),
  a RAM disk (S1:, S2:), and on the PC-1500 the machine-language area
  7C00–7FFF. An entry that doesn't apply right now is greyed out.
- **Module YAML:** the memory module in each slot, as an `initial-content:`
  block for a module definition (see
  [Module definitions](09-module-definitions.md#a-module-with-content-already-on-it)).
- **Clear** (bin icon): empties the log.

Two items of the **Machine** menu belong with it (desktop only):

- **Trace:** starts or stops a CPU instruction trace into a file named
  after the model (`CALCU1500_TRACE.bin`, `CALCU1500A_TRACE.bin`,
  `CALCU1600_TRACE.bin`) in the trace folder (`[trace] folder`); a tick
  shows it runs. The size limit and its notice are the family's
  ([Debugger](../shared/07-debugger.md)).
- **Run Log ▸ Off, Info, Debug:** the log's level, the one in use ticked.
  At Info the log also shows how a preset is carried out, each step as it
  is done; Debug adds nothing yet.

The harness prints the same views without a window:
`calcu --product c1600 c1600 inspect <view>` with `pointers`, `inventory`,
`z80`, `lh`, `basic`, `programs`, `disks`, `physical`, `dump-basic`,
`dump-s1`, `dump-s2`, `dump-disk-s1`, `dump-disk-s2` or `dump-ml`.
